import favicon from "./favicon.png"
import toggledark from "./toggledark.png"
import togglelight from "./togglelight.png"
import emailIcon from "./email.png";
import linkedinIcon from "./linkedin.png";
import githubIcon from "./git.png";
import hfIcon from "./hf.png";
export const assets ={
    favicon,
    toggledark,
    togglelight,
    emailIcon, linkedinIcon, githubIcon, hfIcon 
}